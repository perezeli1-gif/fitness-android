// מאפשר התקנה למסך הבית. תמיד טוען מהרשת כדי שהנתונים יהיו עדכניים.
self.addEventListener('install', e => self.skipWaiting());
self.addEventListener('activate', e => e.waitUntil(self.clients.claim()));
self.addEventListener('fetch', e => {});
