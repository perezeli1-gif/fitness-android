@echo off
chcp 65001 >nul
pip install -r requirements.txt
py web_app.py
pause
