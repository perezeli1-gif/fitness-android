# -*- coding: utf-8 -*-
"""יומן כושר ביתי - שרת ווב (Flask) ל-PythonAnywhere או למחשב מקומי."""
import json, os, re, secrets, sqlite3, time
from datetime import timedelta
from functools import wraps
from flask import Flask, request, session, jsonify, redirect, send_from_directory, Response, g
from werkzeug.security import generate_password_hash, check_password_hash

APP_VERSION = "3.7"
BASE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(BASE, "data")
STATIC = os.path.join(BASE, "static")
DB_PATH = os.path.join(DATA, "fitness.db")
CFG_PATH = os.path.join(DATA, "config.json")
DEFAULT_PASSWORD = "fit2026"
COLLECTIONS = {"profile", "sessions", "measures", "walks", "steps"}

os.makedirs(DATA, exist_ok=True)


def load_cfg():
    cfg = {}
    if os.path.exists(CFG_PATH):
        with open(CFG_PATH, encoding="utf-8") as f:
            cfg = json.load(f)
    changed = False
    if "secret" not in cfg:
        cfg["secret"] = secrets.token_hex(32); changed = True
    if "password_hash" not in cfg:
        cfg["password_hash"] = generate_password_hash(DEFAULT_PASSWORD); changed = True
    if changed:
        save_cfg(cfg)
    return cfg


def save_cfg(cfg):
    tmp = CFG_PATH + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(cfg, f)
    os.replace(tmp, CFG_PATH)


CFG = load_cfg()
app = Flask(__name__, static_folder=None)
app.secret_key = CFG["secret"]
app.config.update(PERMANENT_SESSION_LIFETIME=timedelta(days=365), SESSION_COOKIE_SAMESITE="Lax",
                  MAX_CONTENT_LENGTH=8 * 1024 * 1024)


def db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.execute("CREATE TABLE IF NOT EXISTS docs (col TEXT, id TEXT, data TEXT, updated REAL, PRIMARY KEY(col,id))")
    return g.db


@app.teardown_appcontext
def close_db(_):
    d = g.pop("db", None)
    if d is not None:
        d.close()


def bearer_ok():
    auth = request.headers.get("Authorization", "")
    tok = CFG.get("sync_token")
    return bool(tok) and auth.startswith("Bearer ") and secrets.compare_digest(auth[7:], tok)


def login_required(fn):
    @wraps(fn)
    def wrap(*a, **k):
        if not session.get("ok") and not bearer_ok():
            if request.path.startswith("/api/") or "/api/" in request.path:
                return jsonify({"error": "auth"}), 401
            return redirect("login?nocookie=1" if request.args.get("in") else "login")
        return fn(*a, **k)
    return wrap


LOGIN_HTML = """<!doctype html><html lang="he" dir="rtl"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>יומן כושר ביתי</title>
<link rel="manifest" href="manifest.json"><meta name="theme-color" content="#16201C"><link rel="apple-touch-icon" href="icon-192.png">
<style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#ECEFED;font-family:Arial,sans-serif;color:#16201C}
form{background:#fff;border:1px solid #D3DBD7;border-radius:16px;padding:28px;width:min(340px,90vw);display:flex;flex-direction:column;gap:12px}
h1{margin:0;font-size:26px}input{font-size:17px;padding:10px;border:1px solid #D3DBD7;border-radius:10px}
button{font-size:17px;padding:11px;border:0;border-radius:10px;background:#E3A400;color:#2A1F00;font-weight:700;cursor:pointer}
.err{color:#B3261E;font-size:14px}.pwbox{position:relative}.pwbox input{width:100%;box-sizing:border-box;padding-left:48px}.eye{position:absolute;left:4px;top:50%;transform:translateY(-50%);background:none!important;color:#5A687D!important;padding:6px 8px!important;display:grid;place-items:center}</style></head><body>
<form method="post"><h1>יומן כושר ביתי</h1><label for="pw">סיסמה</label>
<div class="pwbox"><input id="pw" name="password" type="password" autofocus autocomplete="current-password" autocapitalize="none" autocorrect="off" spellcheck="false" dir="ltr">
<button type="button" class="eye" id="eye" aria-label="הצג סיסמה" onclick="var p=document.getElementById('pw'),s=p.type==='password';p.type=s?'text':'password';this.innerHTML=s?EYE_OFF:EYE_ON;this.setAttribute('aria-label',s?'הסתר סיסמה':'הצג סיסמה');p.focus()"></button></div>
<script>var EYE_ON='<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7S1 12 1 12z"/><circle cx="12" cy="12" r="3"/></svg>',EYE_OFF='<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.9 17.9A10.8 10.8 0 0 1 12 19c-7 0-11-7-11-7a19.8 19.8 0 0 1 5.1-5.9M9.9 4.2A10 10 0 0 1 12 4c7 0 11 7 11 7a19.6 19.6 0 0 1-2.2 3.2M1 1l22 22"/><path d="M9.9 9.9a3 3 0 0 0 4.2 4.2"/></svg>';document.getElementById('eye').innerHTML=EYE_ON</script>
<div style="font-size:13px;color:#5A687D">הסיסמה באנגלית: ודא שהמקלדת על אנגלית. לחיצה על העין מציגה מה הקלדת.</div>
%ERR%<button>כניסה</button><div style="text-align:center;color:#5A687D;font-size:13px">גרסה %VER%<br>מפתח האפליקציה · אלי פרץ</div></form></body></html>"""


# נתונים שאלי מסר ב-18.10.2026. נכנסים פעם אחת בלבד, בהפעלה הראשונה של גרסה 1.3.
FIRST_DATA = {
    "date": "2026-10-18",
    "measures": {"weight": 91, "waist": 106, "chest": 116, "shoulders": 116},
    "profile": {"startWeight": 91, "dumbbells": "זוג משקולות 6 · מוט 12"},
}


def seed_once():
    if CFG.get("seed_v13_done"):
        return
    con = sqlite3.connect(DB_PATH)
    try:
        con.execute("CREATE TABLE IF NOT EXISTS docs (col TEXT, id TEXT, data TEXT, updated REAL, PRIMARY KEY(col,id))")
        row = con.execute("SELECT data FROM docs WHERE col='measures' AND id=?", (FIRST_DATA["date"],)).fetchone()
        m = json.loads(row[0]) if row else {}
        m.update(FIRST_DATA["measures"])
        con.execute("INSERT OR REPLACE INTO docs(col,id,data,updated) VALUES('measures',?,?,?)",
                    (FIRST_DATA["date"], json.dumps(m, ensure_ascii=False), time.time()))
        row = con.execute("SELECT data FROM docs WHERE col='profile' AND id='me'").fetchone()
        if row:
            prof = json.loads(row[0])
            prof.update(FIRST_DATA["profile"])
            con.execute("UPDATE docs SET data=?, updated=? WHERE col='profile' AND id='me'",
                        (json.dumps(prof, ensure_ascii=False), time.time()))
        con.commit()
    finally:
        con.close()
    CFG["seed_v13_done"] = True
    save_cfg(CFG)


seed_once()


@app.route("/login", methods=["GET", "POST"])
def login():
    err = ""
    if request.method == "POST":
        pw = request.form.get("password", "")
        if check_password_hash(CFG["password_hash"], pw) or (pw.strip() != pw and check_password_hash(CFG["password_hash"], pw.strip())):
            session.permanent = True
            session["ok"] = True
            return redirect("./?in=1")
        time.sleep(1)
        err = '<div class="err">סיסמה שגויה</div>'
    elif request.args.get("nocookie"):
        err = '<div class="err">הסיסמה נכונה, אבל המכשיר לא שומר את הכניסה (עוגיות חסומות). בדפדפן: הגדרות ← פרטיות ← לאפשר עוגיות לאתר הזה.</div>'
    return LOGIN_HTML.replace("%ERR%", err).replace("%VER%", APP_VERSION)


@app.route("/logout")
def logout():
    session.clear()
    return redirect("login")


def build_page(phone=False):
    """הדף המלא. phone=True: הגרסה שרצה בתוך אפליקציית הטלפון ושומרת את הנתונים בטלפון."""
    with open(os.path.join(STATIC, "app.html"), encoding="utf-8") as f:
        html = f.read()
    m = re.search(r"<title>.*?</title>", html)
    title = m.group(0) if m else "<title>יומן כושר ביתי</title>"
    if m:
        html = html.replace(title, "", 1)
    head = (title + '<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">'
            '<link rel="manifest" href="manifest.json"><meta name="theme-color" content="#16201C">'
            '<link rel="icon" href="icon-192.png"><link rel="apple-touch-icon" href="icon-192.png">'
            '<meta name="apple-mobile-web-app-capable" content="yes">'
            '<style>:root{padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px)}'
            'html,body{height:100%}body{margin:0;font-size:14px}img{max-width:100%}[hidden]{display:none!important}</style>')
    if phone:
        head = head.replace('<link rel="manifest" href="manifest.json">', "")
        html = html.replace("/*SERVER_FLAG*/", "window.FIT_PHONE=true;")
    else:
        html = html.replace("/*SERVER_FLAG*/", "window.FIT_SERVER=true;"
                            "if('serviceWorker' in navigator)navigator.serviceWorker.register('sw.js').catch(function(){});")
    return "<!doctype html><html lang=\"he\" dir=\"rtl\"><head>" + head + "</head><body>" + html + "</body></html>"


@app.route("/")
@login_required
def index():
    return Response(build_page(), mimetype="text/html", headers={"Cache-Control": "no-cache"})


@app.route("/api/app")
@login_required
def api_app():
    """עדכון הדף בתוך אפליקציית הטלפון."""
    return jsonify({"version": APP_VERSION, "html": build_page(phone=True)})


@app.route("/api/token", methods=["POST"])
def api_token():
    """חיבור אפליקציית הטלפון עם הסיסמה. מחזיר קוד חיבור קבוע."""
    pw = (request.get_json(silent=True) or {}).get("password", "")
    if check_password_hash(CFG["password_hash"], pw) or (pw.strip() != pw and check_password_hash(CFG["password_hash"], pw.strip())):
        return jsonify({"ok": True, "token": sync_token(create=True)})
    time.sleep(1)
    return jsonify({"ok": False, "error": "סיסמה שגויה"}), 401


@app.route("/manifest.json")
def manifest():
    return send_from_directory(STATIC, "manifest.json", mimetype="application/manifest+json")


@app.route("/sw.js")
def sw():
    r = send_from_directory(STATIC, "sw.js", mimetype="application/javascript")
    r.headers["Cache-Control"] = "no-cache"
    return r


@app.route("/help")
def help_page():
    r = send_from_directory(STATIC, "help.html", mimetype="text/html")
    r.headers["Cache-Control"] = "no-cache"
    return r


@app.route("/help/<path:name>")
def help_files(name):
    return send_from_directory(os.path.join(STATIC, "help"), name)


@app.route("/<name>.png")
def icons(name):
    if name not in ("icon-192", "icon-512"):
        return "", 404
    return send_from_directory(STATIC, name + ".png")


@app.route("/api/data")
@login_required
def api_data():
    out = {c: {} for c in COLLECTIONS if c != "profile"}
    out["profile"] = None
    for col, id_, data in db().execute("SELECT col,id,data FROM docs"):
        if col == "profile":
            out["profile"] = json.loads(data)
        elif col in out:
            out[col][id_] = json.loads(data)
    r = jsonify(out)
    r.headers["Cache-Control"] = "no-store"
    return r


@app.route("/api/doc/<col>/<id_>", methods=["PUT", "DELETE"])
@login_required
def api_doc(col, id_):
    if col not in COLLECTIONS or len(id_) > 120:
        return jsonify({"error": "bad path"}), 400
    con = db()
    if request.method == "DELETE":
        con.execute("DELETE FROM docs WHERE col=? AND id=?", (col, id_))
    else:
        body = request.get_json(silent=True) or {}
        data = body.get("data")
        if not isinstance(data, dict):
            return jsonify({"error": "bad body"}), 400
        con.execute("INSERT OR REPLACE INTO docs(col,id,data,updated) VALUES(?,?,?,?)",
                    (col, id_, json.dumps(data, ensure_ascii=False), time.time()))
    con.commit()
    return jsonify({"ok": True})


# ---------- סנכרון מאפליקציית הטלפון (Health Connect) ----------
def sync_token(create=False):
    tok = CFG.get("sync_token")
    if not tok and create:
        tok = secrets.token_urlsafe(24)
        CFG["sync_token"] = tok
        save_cfg(CFG)
    return tok


@app.route("/api/sync/token", methods=["GET", "POST"])
@login_required
def api_sync_token():
    # POST = יצירת קוד חדש (מבטל את הקודם)
    if request.method == "POST":
        CFG.pop("sync_token", None)
    return jsonify({"token": sync_token(create=True)})


def _num(v):
    try:
        return None if v is None or v == "" else float(v)
    except (TypeError, ValueError):
        return None


def _hm(t):
    try:
        h, m = str(t).split(":")[:2]
        return int(h) * 60 + int(m)
    except Exception:
        return None


@app.route("/api/sync", methods=["POST"])
def api_sync():
    if not bearer_ok():
        return jsonify({"error": "auth"}), 401
    body = request.get_json(silent=True) or {}
    con = db()
    added = skipped = 0
    months = {}

    def month_doc(m):
        if m not in months:
            row = con.execute("SELECT data FROM docs WHERE col='walks' AND id=?", (m,)).fetchone()
            d = json.loads(row[0]) if row else {}
            d.setdefault("items", {})
            months[m] = d
        return months[m]

    for w in (body.get("walks") or [])[:500]:
        date = str(w.get("date", ""))
        if len(date) != 10 or not str(w.get("id", "")):
            continue
        wid = "hc" + "".join(ch for ch in str(w["id"]) if ch.isalnum())[:40]
        doc = month_doc(date[:7])
        items = doc["items"]
        t0 = _hm(w.get("time"))
        dup = wid in items
        if dup and _num(w.get("rec")) is not None and items[wid].get("rec") is None:
            items[wid]["rec"] = int(_num(w.get("rec")))
        if not dup and t0 is not None:
            for it in items.values():
                if it.get("date") == date and _hm(it.get("time")) is not None and abs(_hm(it.get("time")) - t0) <= 3:
                    dup = True
                    break
        if dup:
            skipped += 1
            continue
        mins = _num(w.get("min"))
        items[wid] = {"id": wid, "date": date, "time": str(w.get("time") or "")[:5],
                      "min": round(mins) if mins else None,
                      "km": round(_num(w.get("km")), 2) if _num(w.get("km")) else None,
                      "steps": int(_num(w.get("steps"))) if _num(w.get("steps")) else None,
                      "hr": round(_num(w.get("hr"))) if _num(w.get("hr")) else None,
                      "kcal": round(_num(w.get("kcal"))) if _num(w.get("kcal")) else None,
                      "rec": int(_num(w.get("rec"))) if _num(w.get("rec")) is not None else None,
                      "src": "watch"}
        added += 1
    for m, d in months.items():
        con.execute("INSERT OR REPLACE INTO docs(col,id,data,updated) VALUES('walks',?,?,?)",
                    (m, json.dumps(d, ensure_ascii=False), time.time()))
    days = 0
    steps = body.get("steps") or {}
    by_m = {}
    for date, cnt in list(steps.items())[:400]:
        c = _num(cnt)
        if len(str(date)) == 10 and c is not None:
            by_m.setdefault(date[:7], {})[date] = int(c)
    for m, vals in by_m.items():
        row = con.execute("SELECT data FROM docs WHERE col='steps' AND id=?", (m,)).fetchone()
        d = json.loads(row[0]) if row else {}
        d.setdefault("days", {}).update(vals)
        days += len(vals)
        con.execute("INSERT OR REPLACE INTO docs(col,id,data,updated) VALUES('steps',?,?,?)",
                    (m, json.dumps(d, ensure_ascii=False), time.time()))
    con.commit()
    return jsonify({"ok": True, "added": added, "skipped": skipped, "stepDays": days})


@app.route("/api/backup")
@login_required
def api_backup():
    d = api_data().get_json()
    d.update({"app": "fitness-log", "version": 2, "exported": time.strftime("%Y-%m-%dT%H:%M:%S")})
    name = "fitness-backup-" + time.strftime("%Y-%m-%d") + ".json"
    return Response(json.dumps(d, ensure_ascii=False, indent=1), mimetype="application/json",
                    headers={"Content-Disposition": "attachment; filename=" + name})


@app.route("/api/password", methods=["POST"])
@login_required
def api_password():
    b = request.get_json(silent=True) or {}
    if not check_password_hash(CFG["password_hash"], b.get("current", "")):
        return jsonify({"ok": False, "error": "הסיסמה הנוכחית שגויה"})
    new = b.get("new", "")
    if len(new) < 4:
        return jsonify({"ok": False, "error": "הסיסמה החדשה קצרה מדי (4 תווים לפחות)"})
    CFG["password_hash"] = generate_password_hash(new)
    save_cfg(CFG)
    return jsonify({"ok": True})


@app.route("/api/version")
def api_version():
    return jsonify({"version": APP_VERSION})


if __name__ == "__main__":
    print("יומן כושר ביתי פועל: http://localhost:5050  (סיסמה ראשונית: %s)" % DEFAULT_PASSWORD)
    app.run(host="0.0.0.0", port=5050, debug=False)
