# -*- coding: utf-8 -*-
"""יומן כושר ביתי - שרת ווב (Flask) ל-PythonAnywhere או למחשב מקומי."""
import json, os, re, secrets, sqlite3, time
from datetime import timedelta
from functools import wraps
from flask import Flask, request, session, jsonify, redirect, send_from_directory, send_file, Response, g
from werkzeug.security import generate_password_hash, check_password_hash

APP_VERSION = "6.6"
BASE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(BASE, "data")
STATIC = os.path.join(BASE, "static")
DB_PATH = os.path.join(DATA, "fitness.db")
CFG_PATH = os.path.join(DATA, "config.json")
DEFAULT_PASSWORD = "fit2026"
COLLECTIONS = {"profile", "sessions", "measures", "walks", "steps"}

os.makedirs(DATA, exist_ok=True)


def load_cfg():
    cfg = {}
    if os.path.exists(CFG_PATH):
        with open(CFG_PATH, encoding="utf-8") as f:
            cfg = json.load(f)
    changed = False
    if "secret" not in cfg:
        cfg["secret"] = secrets.token_hex(32); changed = True
    if "password_hash" not in cfg:
        cfg["password_hash"] = generate_password_hash(DEFAULT_PASSWORD); changed = True
    if changed:
        save_cfg(cfg)
    return cfg


def save_cfg(cfg):
    tmp = CFG_PATH + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(cfg, f)
    os.replace(tmp, CFG_PATH)


CFG = load_cfg()
app = Flask(__name__, static_folder=None)
app.secret_key = CFG["secret"]
app.config.update(PERMANENT_SESSION_LIFETIME=timedelta(days=180), SESSION_COOKIE_SAMESITE="Strict",
                  SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_NAME="fit_s", MAX_CONTENT_LENGTH=8 * 1024 * 1024)

# ---------- אבטחה ----------
SEC_LOG = os.path.join(DATA, "security.log")
FAILS = {}            # ip -> [זמני ניסיונות שגויים]
LOCK_AFTER, LOCK_SECS = 5, 15 * 60
CSP = ("default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; "
       "font-src 'self' data: https://fonts.gstatic.com; img-src 'self' data: blob:; connect-src 'self'; "
       "frame-ancestors 'none'; base-uri 'none'; form-action 'self'; object-src 'none'")


def client_ip():
    ip = request.remote_addr or "?"
    if ip in ("127.0.0.1", "::1"):   # דרך Tailscale: הכתובת האמיתית בכותרת
        ip = (request.headers.get("X-Forwarded-For", "").split(",")[0].strip() or ip)
    return ip


def sec_log(event):
    try:
        with open(SEC_LOG, "a", encoding="utf-8") as f:
            f.write("%s\t%s\t%s\t%s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), event, client_ip(),
                                          (request.headers.get("User-Agent") or "")[:80]))
        if os.path.getsize(SEC_LOG) > 512 * 1024:      # שומרים רק את החלק האחרון
            with open(SEC_LOG, encoding="utf-8") as f:
                tail = f.readlines()[-2000:]
            with open(SEC_LOG, "w", encoding="utf-8") as f:
                f.writelines(tail)
    except OSError:
        pass


def locked():
    now = time.time()
    lst = [t for t in FAILS.get(client_ip(), []) if now - t < LOCK_SECS]
    FAILS[client_ip()] = lst
    return len(lst) >= LOCK_AFTER


def check_pw(pw, where):
    """בדיקת סיסמה עם חסימה אחרי 5 ניסיונות שגויים ל-15 דקות, ורישום ביומן האבטחה."""
    if locked():
        sec_log("blocked-" + where)
        return None
    ok = check_password_hash(CFG["password_hash"], pw) or (pw.strip() != pw and check_password_hash(CFG["password_hash"], pw.strip()))
    if ok:
        FAILS.pop(client_ip(), None)
        sec_log("login-ok-" + where)
    else:
        FAILS.setdefault(client_ip(), []).append(time.time())
        sec_log("login-fail-" + where)
        time.sleep(1)
    return ok


def default_password():
    return check_password_hash(CFG["password_hash"], DEFAULT_PASSWORD)


@app.before_request
def prefer_https():
    """כניסה דרך הרשת הביתית בלי הצפנה (http) מועברת לכתובת המאובטחת (https דרך Tailscale).
    רק לדפים: בקשות ה-API ממשיכות לעבוד גם בכתובת הביתית (לבודק השרת)."""
    url = CFG.get("public_url")
    if not url or request.headers.get("X-Forwarded-Proto") == "https" or request.is_secure:
        return None
    host = (request.host or "").split(":")[0]
    pub = url.split("//", 1)[-1].split("/")[0].split(":")[0]
    if host == pub or not host.startswith("192.168.") or host in ("127.0.0.1", "localhost") or request.path.startswith("/api/") or request.path.startswith("/apk/") or request.path.startswith("/music/"):
        return None
    if request.method == "GET":
        return redirect(url.rstrip("/") + request.full_path.rstrip("?"), code=302)
    return None


@app.after_request
def security_headers(r):
    h = r.headers
    h.setdefault("X-Content-Type-Options", "nosniff")
    h.setdefault("X-Frame-Options", "DENY")
    h.setdefault("Referrer-Policy", "no-referrer")
    h.setdefault("Permissions-Policy", "camera=(), microphone=(), geolocation=(), payment=()")
    h.setdefault("Cross-Origin-Opener-Policy", "same-origin")
    if r.mimetype == "text/html":
        h.setdefault("Content-Security-Policy", CSP)
    if request.headers.get("X-Forwarded-Proto") == "https":
        h.setdefault("Strict-Transport-Security", "max-age=31536000")
    h.pop("Server", None)
    return r


def db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.execute("CREATE TABLE IF NOT EXISTS docs (col TEXT, id TEXT, data TEXT, updated REAL, PRIMARY KEY(col,id))")
    return g.db


@app.teardown_appcontext
def close_db(_):
    d = g.pop("db", None)
    if d is not None:
        d.close()


def bearer_ok():
    auth = request.headers.get("Authorization", "")
    tok = CFG.get("sync_token")
    if tok and request.path.startswith("/music/") and request.args.get("t"):   # נגן שלא יכול לשלוח כותרת
        return secrets.compare_digest(request.args.get("t"), tok)
    return bool(tok) and auth.startswith("Bearer ") and secrets.compare_digest(auth[7:], tok)


def login_required(fn):
    @wraps(fn)
    def wrap(*a, **k):
        if not session.get("ok") and not bearer_ok():
            if request.path.startswith("/api/") or "/api/" in request.path:
                return jsonify({"error": "auth"}), 401
            return redirect("login?nocookie=1" if request.args.get("in") else "login")
        return fn(*a, **k)
    return wrap


LOGIN_HTML = """<!doctype html><html lang="he" dir="rtl"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>יומן כושר ביתי</title>
<link rel="manifest" href="manifest.json"><meta name="theme-color" content="#16201C"><link rel="apple-touch-icon" href="icon-192.png">
<style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#ECEFED;font-family:Arial,sans-serif;color:#16201C}
form{background:#fff;border:1px solid #D3DBD7;border-radius:16px;padding:28px;width:min(340px,90vw);display:flex;flex-direction:column;gap:12px}
h1{margin:0;font-size:26px}input{font-size:17px;padding:10px;border:1px solid #D3DBD7;border-radius:10px}
button{font-size:17px;padding:11px;border:0;border-radius:10px;background:#E3A400;color:#2A1F00;font-weight:700;cursor:pointer}
.err{color:#B3261E;font-size:14px}.pwbox{position:relative}.pwbox input{width:100%;box-sizing:border-box;padding-left:48px}.eye{position:absolute;left:4px;top:50%;transform:translateY(-50%);background:none!important;color:#5A687D!important;padding:6px 8px!important;display:grid;place-items:center}</style></head><body>
<form method="post"><h1>יומן כושר ביתי</h1><label for="pw">סיסמה</label>
<div class="pwbox"><input id="pw" name="password" type="password" autofocus autocomplete="current-password" autocapitalize="none" autocorrect="off" spellcheck="false" dir="ltr">
<button type="button" class="eye" id="eye" aria-label="הצג סיסמה" onclick="var p=document.getElementById('pw'),s=p.type==='password';p.type=s?'text':'password';this.innerHTML=s?EYE_OFF:EYE_ON;this.setAttribute('aria-label',s?'הסתר סיסמה':'הצג סיסמה');p.focus()"></button></div>
<script>var EYE_ON='<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7S1 12 1 12z"/><circle cx="12" cy="12" r="3"/></svg>',EYE_OFF='<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.9 17.9A10.8 10.8 0 0 1 12 19c-7 0-11-7-11-7a19.8 19.8 0 0 1 5.1-5.9M9.9 4.2A10 10 0 0 1 12 4c7 0 11 7 11 7a19.6 19.6 0 0 1-2.2 3.2M1 1l22 22"/><path d="M9.9 9.9a3 3 0 0 0 4.2 4.2"/></svg>';document.getElementById('eye').innerHTML=EYE_ON</script>
<div style="font-size:13px;color:#5A687D">הסיסמה באנגלית: ודא שהמקלדת על אנגלית. לחיצה על העין מציגה מה הקלדת.</div>
%ERR%<button>כניסה</button><div style="text-align:center;color:#5A687D;font-size:13px">גרסה %VER%<br>מפתח האפליקציה · אלי פרץ</div></form></body></html>"""


# נתונים שאלי מסר ב-18.10.2026. נכנסים פעם אחת בלבד, בהפעלה הראשונה של גרסה 1.3.
FIRST_DATA = {
    "date": "2026-10-18",
    "measures": {"weight": 91, "waist": 106, "chest": 116, "shoulders": 116},
    "profile": {"startWeight": 91, "dumbbells": "זוג משקולות 6 · מוט 12"},
}


def seed_once():
    if CFG.get("seed_v13_done"):
        return
    con = sqlite3.connect(DB_PATH)
    try:
        con.execute("CREATE TABLE IF NOT EXISTS docs (col TEXT, id TEXT, data TEXT, updated REAL, PRIMARY KEY(col,id))")
        row = con.execute("SELECT data FROM docs WHERE col='measures' AND id=?", (FIRST_DATA["date"],)).fetchone()
        m = json.loads(row[0]) if row else {}
        m.update(FIRST_DATA["measures"])
        con.execute("INSERT OR REPLACE INTO docs(col,id,data,updated) VALUES('measures',?,?,?)",
                    (FIRST_DATA["date"], json.dumps(m, ensure_ascii=False), time.time()))
        row = con.execute("SELECT data FROM docs WHERE col='profile' AND id='me'").fetchone()
        if row:
            prof = json.loads(row[0])
            prof.update(FIRST_DATA["profile"])
            con.execute("UPDATE docs SET data=?, updated=? WHERE col='profile' AND id='me'",
                        (json.dumps(prof, ensure_ascii=False), time.time()))
        con.commit()
    finally:
        con.close()
    CFG["seed_v13_done"] = True
    save_cfg(CFG)


seed_once()


@app.route("/login", methods=["GET", "POST"])
def login():
    err = ""
    if request.method == "POST":
        pw = request.form.get("password", "")
        ok = check_pw(pw, "web")
        if ok:
            session.clear()
            session.permanent = True
            session["ok"] = True
            return redirect("./?in=1")
        err = ('<div class="err">יותר מדי ניסיונות שגויים. נסה שוב בעוד 15 דקות.</div>' if ok is None
               else '<div class="err">סיסמה שגויה</div>')
    elif request.args.get("nocookie"):
        err = '<div class="err">הסיסמה נכונה, אבל המכשיר לא שומר את הכניסה (עוגיות חסומות). בדפדפן: הגדרות ← פרטיות ← לאפשר עוגיות לאתר הזה.</div>'
    return LOGIN_HTML.replace("%ERR%", err).replace("%VER%", APP_VERSION)


@app.route("/logout")
def logout():
    session.clear()
    return redirect("login")


def build_page(phone=False):
    """הדף המלא. phone=True: הגרסה שרצה בתוך אפליקציית הטלפון ושומרת את הנתונים בטלפון."""
    with open(os.path.join(STATIC, "app.html"), encoding="utf-8") as f:
        html = f.read()
    m = re.search(r"<title>.*?</title>", html)
    title = m.group(0) if m else "<title>יומן כושר ביתי</title>"
    if m:
        html = html.replace(title, "", 1)
    head = (title + '<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">'
            '<link rel="manifest" href="manifest.json"><meta name="theme-color" content="#16201C">'
            '<link rel="icon" href="icon-192.png"><link rel="apple-touch-icon" href="icon-192.png">'
            '<meta name="apple-mobile-web-app-capable" content="yes">'
            '<style>:root{padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px)}'
            'html,body{height:100%}body{margin:0;font-size:14px}img{max-width:100%}[hidden]{display:none!important}</style>')
    if phone:
        head = head.replace('<link rel="manifest" href="manifest.json">', "")
        html = html.replace("/*SERVER_FLAG*/", "window.FIT_PHONE=true;")
    else:
        html = html.replace("/*SERVER_FLAG*/", "window.FIT_SERVER=true;"
                            "if('serviceWorker' in navigator)navigator.serviceWorker.register('sw.js').catch(function(){});")
    return "<!doctype html><html lang=\"he\" dir=\"rtl\"><head>" + head + "</head><body>" + html + "</body></html>"


@app.route("/")
@login_required
def index():
    return Response(build_page(), mimetype="text/html", headers={"Cache-Control": "no-cache"})


@app.route("/api/app")
@login_required
def api_app():
    """עדכון הדף בתוך אפליקציית הטלפון."""
    return jsonify({"version": APP_VERSION, "html": build_page(phone=True)})


@app.route("/api/token", methods=["POST"])
def api_token():
    """חיבור אפליקציית הטלפון עם הסיסמה. מחזיר קוד חיבור קבוע."""
    pw = (request.get_json(silent=True) or {}).get("password", "")
    ok = check_pw(pw, "phone")
    if ok:
        return jsonify({"ok": True, "token": sync_token(create=True)})
    if ok is None:
        return jsonify({"ok": False, "error": "יותר מדי ניסיונות שגויים. נסה שוב בעוד 15 דקות."}), 429
    return jsonify({"ok": False, "error": "סיסמה שגויה"}), 401


@app.route("/manifest.json")
def manifest():
    return send_from_directory(STATIC, "manifest.json", mimetype="application/manifest+json")


@app.route("/sw.js")
def sw():
    r = send_from_directory(STATIC, "sw.js", mimetype="application/javascript")
    r.headers["Cache-Control"] = "no-cache"
    return r


@app.route("/help")
def help_page():
    r = send_from_directory(STATIC, "help.html", mimetype="text/html")
    r.headers["Cache-Control"] = "no-cache"
    return r


@app.route("/help/<path:name>")
def help_files(name):
    return send_from_directory(os.path.join(STATIC, "help"), name)


@app.route("/<name>.png")
def icons(name):
    if name not in ("icon-192", "icon-512"):
        return "", 404
    return send_from_directory(STATIC, name + ".png")


@app.route("/api/data")
@login_required
def api_data():
    out = {c: {} for c in COLLECTIONS if c != "profile"}
    out["profile"] = None
    for col, id_, data in db().execute("SELECT col,id,data FROM docs"):
        if col == "profile":
            out["profile"] = json.loads(data)
        elif col in out:
            out[col][id_] = json.loads(data)
    r = jsonify(out)
    r.headers["Cache-Control"] = "no-store"
    return r


@app.route("/api/doc/<col>/<id_>", methods=["PUT", "DELETE"])
@login_required
def api_doc(col, id_):
    if col not in COLLECTIONS or len(id_) > 120:
        return jsonify({"error": "bad path"}), 400
    con = db()
    if request.method == "DELETE":
        con.execute("DELETE FROM docs WHERE col=? AND id=?", (col, id_))
    else:
        body = request.get_json(silent=True) or {}
        data = body.get("data")
        if not isinstance(data, dict):
            return jsonify({"error": "bad body"}), 400
        con.execute("INSERT OR REPLACE INTO docs(col,id,data,updated) VALUES(?,?,?,?)",
                    (col, id_, json.dumps(data, ensure_ascii=False), time.time()))
    con.commit()
    return jsonify({"ok": True})


# ---------- סנכרון מאפליקציית הטלפון (Health Connect) ----------
def sync_token(create=False):
    tok = CFG.get("sync_token")
    if not tok and create:
        tok = secrets.token_urlsafe(24)
        CFG["sync_token"] = tok
        save_cfg(CFG)
    return tok


@app.route("/api/sync/token", methods=["GET", "POST"])
@login_required
def api_sync_token():
    # POST = יצירת קוד חדש (מבטל את הקודם)
    if request.method == "POST":
        CFG.pop("sync_token", None)
    return jsonify({"token": sync_token(create=True)})


def _num(v):
    try:
        return None if v is None or v == "" else float(v)
    except (TypeError, ValueError):
        return None


def _hm(t):
    try:
        h, m = str(t).split(":")[:2]
        return int(h) * 60 + int(m)
    except Exception:
        return None


@app.route("/api/sync", methods=["POST"])
def api_sync():
    if not bearer_ok():
        return jsonify({"error": "auth"}), 401
    body = request.get_json(silent=True) or {}
    con = db()
    added = skipped = 0
    months = {}

    def month_doc(m):
        if m not in months:
            row = con.execute("SELECT data FROM docs WHERE col='walks' AND id=?", (m,)).fetchone()
            d = json.loads(row[0]) if row else {}
            d.setdefault("items", {})
            months[m] = d
        return months[m]

    for w in (body.get("walks") or [])[:500]:
        date = str(w.get("date", ""))
        if len(date) != 10 or not str(w.get("id", "")):
            continue
        wid = "hc" + "".join(ch for ch in str(w["id"]) if ch.isalnum())[:40]
        doc = month_doc(date[:7])
        items = doc["items"]
        t0 = _hm(w.get("time"))
        dup = wid in items
        if dup and _num(w.get("rec")) is not None and items[wid].get("rec") is None:
            items[wid]["rec"] = int(_num(w.get("rec")))
        if not dup and t0 is not None:
            for it in items.values():
                if it.get("date") == date and _hm(it.get("time")) is not None and abs(_hm(it.get("time")) - t0) <= 3:
                    dup = True
                    break
        if dup:
            skipped += 1
            continue
        mins = _num(w.get("min"))
        items[wid] = {"id": wid, "date": date, "time": str(w.get("time") or "")[:5],
                      "min": round(mins) if mins else None,
                      "km": round(_num(w.get("km")), 2) if _num(w.get("km")) else None,
                      "steps": int(_num(w.get("steps"))) if _num(w.get("steps")) else None,
                      "hr": round(_num(w.get("hr"))) if _num(w.get("hr")) else None,
                      "kcal": round(_num(w.get("kcal"))) if _num(w.get("kcal")) else None,
                      "rec": int(_num(w.get("rec"))) if _num(w.get("rec")) is not None else None,
                      "src": "watch"}
        added += 1
    for m, d in months.items():
        con.execute("INSERT OR REPLACE INTO docs(col,id,data,updated) VALUES('walks',?,?,?)",
                    (m, json.dumps(d, ensure_ascii=False), time.time()))
    days = 0
    steps = body.get("steps") or {}
    by_m = {}
    for date, cnt in list(steps.items())[:400]:
        c = _num(cnt)
        if len(str(date)) == 10 and c is not None:
            by_m.setdefault(date[:7], {})[date] = int(c)
    for m, vals in by_m.items():
        row = con.execute("SELECT data FROM docs WHERE col='steps' AND id=?", (m,)).fetchone()
        d = json.loads(row[0]) if row else {}
        d.setdefault("days", {}).update(vals)
        days += len(vals)
        con.execute("INSERT OR REPLACE INTO docs(col,id,data,updated) VALUES('steps',?,?,?)",
                    (m, json.dumps(d, ensure_ascii=False), time.time()))
    con.commit()
    return jsonify({"ok": True, "added": added, "skipped": skipped, "stepDays": days})


@app.route("/api/backup")
@login_required
def api_backup():
    d = api_data().get_json()
    d.update({"app": "fitness-log", "version": 2, "exported": time.strftime("%Y-%m-%dT%H:%M:%S")})
    name = "fitness-backup-" + time.strftime("%Y-%m-%d") + ".json"
    return Response(json.dumps(d, ensure_ascii=False, indent=1), mimetype="application/json",
                    headers={"Content-Disposition": "attachment; filename=" + name})


@app.route("/api/password", methods=["POST"])
@login_required
def api_password():
    b = request.get_json(silent=True) or {}
    ok = check_pw(b.get("current", ""), "change")
    if not ok:
        return jsonify({"ok": False, "error": "יותר מדי ניסיונות. נסה בעוד 15 דקות." if ok is None else "הסיסמה הנוכחית שגויה"})
    new = b.get("new", "")
    if len(new) < 8:
        return jsonify({"ok": False, "error": "הסיסמה החדשה קצרה מדי: לפחות 8 תווים"})
    if new == DEFAULT_PASSWORD or new.lower() in ("12345678", "password", "fitness1", "11111111"):
        return jsonify({"ok": False, "error": "הסיסמה הזו קלה מדי לניחוש. בחר אחרת"})
    CFG["password_hash"] = generate_password_hash(new)
    save_cfg(CFG)
    sec_log("password-changed")
    return jsonify({"ok": True})


@app.route("/api/security")
@login_required
def api_security():
    """מצב האבטחה לדף: האם הסיסמה עדיין סיסמת ההתחלה, וניסיונות שגויים אחרונים."""
    fails = 0
    try:
        cut = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(time.time() - 7 * 86400))
        with open(SEC_LOG, encoding="utf-8") as f:
            fails = sum(1 for ln in f if "login-fail" in ln and ln[:19] >= cut)
    except OSError:
        pass
    return jsonify({"default_password": default_password(), "fails_7d": fails})


@app.route("/api/version")
def api_version():
    return jsonify({"version": APP_VERSION})


# ---------- מוזיקה: הספרייה נשארת במחשב, והשרת קורא אותה דרך שיתוף תיקייה (SMB) ----------
import threading, mimetypes, io
MUSIC = os.environ.get("FIT_MUSIC", os.path.join(BASE, "music"))   # תיקייה מקומית (אם אין שיתוף)
SMB_CFG = os.path.join(DATA, "music-smb.json")
MIDX_PATH = os.path.join(DATA, "music-index.json")
AUDIO_EXT = (".mp3", ".m4a", ".aac", ".ogg", ".opus", ".flac", ".wav", ".wma")
SKIP_DIRS = ("$recycle.bin", "system volume information")
_M = {"files": None, "t": 0, "building": False, "err": "", "lock": threading.Lock()}


def smb_cfg():
    try:
        with open(SMB_CFG, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return None


def smb_conn(c):
    """חיבור למחשב: קודם בכתובת הביתית, ואם לא עונה, בכתובת השנייה (Tailscale)."""
    from smb.SMBConnection import SMBConnection
    last = None
    for host in [h for h in (c.get("host"), c.get("alt")) if h]:
        conn = SMBConnection(c["user"], c["password"], "fitness-server", c.get("name", "PC"), use_ntlm_v2=True, is_direct_tcp=True)
        try:
            if conn.connect(host, int(c.get("port", 445)), timeout=6):
                return conn
            last = OSError("login failed")
        except Exception as e:
            last = e
    raise last or OSError("no address")


def _build_index():
    c = smb_cfg()
    out = []
    try:
        if c:
            conn = smb_conn(c)
            try:
                stack = [""]
                while stack:
                    d = stack.pop()
                    for f in conn.listPath(c["share"], "/" + d if d else "/", timeout=30):
                        n = f.filename
                        if n in (".", "..") or n.lower() in SKIP_DIRS:
                            continue
                        rel = (d + "/" + n) if d else n
                        if f.isDirectory:
                            stack.append(rel)
                        elif n.lower().endswith(AUDIO_EXT):
                            out.append((rel, f.file_size))
            finally:
                conn.close()
        elif os.path.isdir(MUSIC):
            for root, dirs, files in os.walk(MUSIC):
                for fn in files:
                    if fn.lower().endswith(AUDIO_EXT):
                        full = os.path.join(root, fn)
                        out.append((os.path.relpath(full, MUSIC).replace(os.sep, "/"), os.path.getsize(full)))
        out.sort()
        _M.update(files=out, t=time.time(), err="")
        tmp = MIDX_PATH + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump({"t": _M["t"], "files": out}, f, ensure_ascii=False)
        os.replace(tmp, MIDX_PATH)
    except Exception as e:      # המחשב כבוי או לא נגיש: משאירים את הרשימה הקודמת
        _M["err"] = str(e)[:200]
    finally:
        _M["building"] = False


def music_rescan():
    with _M["lock"]:
        if _M["building"]:
            return
        _M["building"] = True
    threading.Thread(target=_build_index, daemon=True).start()


def music_index():
    if _M["files"] is None:
        try:
            with open(MIDX_PATH, encoding="utf-8") as f:
                d = json.load(f)
            _M.update(files=[tuple(x) for x in d["files"]], t=d["t"])
        except (OSError, ValueError, KeyError):
            _M["files"] = []
    try:
        cfg_changed = os.path.getmtime(SMB_CFG) > _M["t"]
    except OSError:
        cfg_changed = False
    if time.time() - _M["t"] > 6 * 3600 or cfg_changed:
        music_rescan()
    return _M["files"]


def _clean_rel(rel):
    parts = [p for p in (rel or "").replace("\\", "/").split("/") if p not in ("", ".")]
    if ".." in parts:
        return None
    return "/".join(parts)


@app.route("/api/music/status")
@login_required
def api_music_status():
    music_index()
    return jsonify({"source": "pc" if smb_cfg() else "server", "count": len(_M["files"] or []),
                    "indexed": _M["t"], "building": _M["building"], "error": _M["err"]})


MUSIC_LOG = os.path.join(DATA, "music.log")


@app.after_request
def music_log(r):
    """יומן קצר של בקשות המוזיקה, לאבחון תקלות."""
    if request.path.startswith("/music/") or request.path.startswith("/api/music"):
        try:
            with open(MUSIC_LOG, "a", encoding="utf-8") as f:
                f.write("%s\t%s\t%s\t%s\t%s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), r.status_code, request.path[:90],
                                                  request.headers.get("Range", "-"), (request.headers.get("User-Agent") or "")[:60]))
            if os.path.getsize(MUSIC_LOG) > 300 * 1024:
                with open(MUSIC_LOG, encoding="utf-8") as f:
                    tail = f.readlines()[-1500:]
                with open(MUSIC_LOG, "w", encoding="utf-8") as f:
                    f.writelines(tail)
        except OSError:
            pass
    return r


@app.route("/api/music/check")
@login_required
def api_music_check():
    """בדיקת חיבור: האם המחשב עם המוזיקה עונה עכשיו."""
    c = smb_cfg()
    if not c:
        return jsonify({"ok": os.path.isdir(MUSIC), "source": "server", "count": len(music_index())})
    try:
        conn = smb_conn(c)
        conn.listPath(c["share"], "/", timeout=10)
        conn.close()
        return jsonify({"ok": True, "source": "pc", "count": len(music_index()), "building": _M["building"]})
    except Exception as e:
        return jsonify({"ok": False, "source": "pc", "count": len(music_index()), "error": "המחשב כבוי, במצב שינה, או לא מחובר לרשת"})


@app.route("/api/music/rescan", methods=["POST"])
@login_required
def api_music_rescan():
    music_rescan()
    return jsonify({"ok": True})


@app.route("/api/music/list")
@login_required
def api_music_list():
    """תיקייה אחת: תתי-תיקיות (עם מספר השירים בהן) ושירים."""
    d = (request.args.get("dir") or "").strip("/")
    pre = d + "/" if d else ""
    dirs, files = {}, []
    for rel, size in music_index():
        if not rel.startswith(pre):
            continue
        rest = rel[len(pre):]
        if "/" in rest:
            k = rest.split("/", 1)[0]
            dirs[k] = dirs.get(k, 0) + 1
        else:
            files.append({"n": rest, "s": size})
    r = jsonify({"dir": d, "dirs": [{"n": k, "c": v} for k, v in sorted(dirs.items())], "files": files,
                 "total": len(_M["files"] or []), "building": _M["building"], "error": _M["err"]})
    r.headers["Cache-Control"] = "no-store"
    return r


MRECENT = os.path.join(DATA, "music-recent.json")
MPLAYABLE = (".mp3", ".m4a", ".aac")
MCACHE = os.path.join(DATA, "mcache")
MCACHE_MAX = 3 * 1024 ** 3
# סוגי מוזיקה לבחירה אקראית: תיקייה ראשית בספרייה
MCATS = {"il": ("01 - ", "02 - "), "mz": ("06 - ", "02 - אוספים/07 - "), "lz": ("09 - ",), "dt": ("03 - ",)}
MSKIP = re.compile(r"זיכרון|זכרון|הנצחה|משוררים|נשמת|חזן|תפיל|סליחות|קריוקי|karaoke|פלייבק|playback|instrumental|אינסטרומנטלי|ילדים|שירי ערש|מצחיק|סיפור|הקראה|מונולוג|ראיון|מערכון|מערכונים|סטנדאפ", re.I)
MHITS = re.compile(r"להיטים|הלהיטים|הגדולים|המיטב|הטובים|האוסף|אוסף|best|greatest|hits|הכי", re.I)
MLIVE = re.compile(r"הופעה|הופעות|במופע|live|לייב|unplugged", re.I)
_MPOOL = {"t": 0, "key": None, "groups": None}


def music_pool(cats):
    """השירים המתאימים, מקובצים לפי זמר. זמרים עם הרבה שירים בספרייה הם בדרך כלל המוכרים."""
    key = (tuple(sorted(cats)), _M.get("t"))
    if _MPOOL["key"] == key:
        return _MPOOL["groups"]
    pref = tuple(p for c in cats for p in MCATS.get(c, ()))
    groups = {}
    for rel, size in music_index():
        if size < 1024 * 1024 or not rel.lower().endswith(MPLAYABLE) or not rel.startswith(pref) or MSKIP.search(rel):
            continue
        parts = rel.split("/")
        if rel.startswith("01 - ") and len(parts) >= 4:
            who = parts[2]
        elif len(parts) >= 3:
            who = "/".join(parts[:2])        # אוסף: כל קטגוריה של אוספים היא "זמר" אחד
        else:
            continue
        if who == "000" or MLIVE.search(rel):      # הקלטות מהופעות: מדברים, מחיאות כפיים
            continue
        groups.setdefault(who, []).append(rel)
    _MPOOL.update(key=key, groups=groups)
    return groups


def mcache_path(rel):
    import hashlib
    return os.path.join(MCACHE, hashlib.sha1(rel.encode("utf-8")).hexdigest() + os.path.splitext(rel)[1].lower())


def mcache_fill(rels):
    """מעתיק את השירים שנבחרו מהמחשב לשרת מראש, כדי שבהליכה הם יגיעו מהר ובלי עצירות."""
    c = smb_cfg()
    if not c:
        return
    os.makedirs(MCACHE, exist_ok=True)
    try:
        conn = smb_conn(c)
    except Exception:
        return
    try:
        for rel in rels:
            dst = mcache_path(rel)
            if os.path.exists(dst):
                os.utime(dst, None)
                continue
            tmp = dst + ".part"
            try:
                with open(tmp, "wb") as f:
                    conn.retrieveFile(c["share"], "/" + rel, f, timeout=60)
                os.replace(tmp, dst)
            except Exception:
                try:
                    os.remove(tmp)
                except OSError:
                    pass
    finally:
        conn.close()
    try:   # שומרים עד 3 ג"ב: מוחקים את הישנים
        fs = sorted((os.path.join(MCACHE, n) for n in os.listdir(MCACHE) if not n.endswith(".part")), key=os.path.getmtime)
        tot = sum(os.path.getsize(f) for f in fs)
        while fs and tot > MCACHE_MAX:
            f = fs.pop(0)
            tot -= os.path.getsize(f)
            os.remove(f)
    except OSError:
        pass


@app.route("/api/music/random")
@login_required
def api_music_random():
    """רשימת השמעה אקראית: בעיקר זמרים מוכרים ושירים מאוספי להיטים, בלי שירים שיצאו לאחרונה."""
    import random
    n = max(1, min(int(request.args.get("n") or 30), 60))
    cats = [c for c in (request.args.get("cats") or "il,mz").split(",") if c in MCATS] or ["il", "mz"]
    try:
        with open(MRECENT, encoding="utf-8") as f:
            recent = json.load(f)
    except (OSError, ValueError):
        recent = []
    seen = set(recent)
    groups = music_pool(cats)
    # זמרים מוכרים: 100 שירים ומעלה בספרייה. קבוצות האוספים תמיד בפנים.
    famous = {k: v for k, v in groups.items() if len(v) >= 100 or "/" in k}
    if len(famous) < 10:
        famous = groups
    names = list(famous)
    weights = [len(famous[k]) ** 0.5 for k in names]
    pick, used_who, tries = [], {}, 0
    while len(pick) < n and tries < n * 40 and names:
        tries += 1
        who = random.choices(names, weights)[0]
        if used_who.get(who, 0) >= 2:            # לא יותר משני שירים של אותו זמר
            continue
        songs = [r for r in famous[who] if r not in seen]
        if not songs:
            continue
        hits = [r for r in songs if MHITS.search(r)]
        r = random.choice(hits if hits and random.random() < 0.7 else songs)
        pick.append(r)
        seen.add(r)
        used_who[who] = used_who.get(who, 0) + 1
    if len(pick) < n // 2:     # כמעט הכול כבר יצא: מתחילים מחדש
        recent = []
    recent = (recent + pick)[-3000:]
    try:
        with open(MRECENT, "w", encoding="utf-8") as f:
            json.dump(recent, f, ensure_ascii=False)
    except OSError:
        pass
    threading.Thread(target=mcache_fill, args=(pick,), daemon=True).start()
    return jsonify({"files": [{"p": r} for r in pick], "total": sum(len(v) for v in famous.values())})


@app.route("/api/music/all")
@login_required
def api_music_all():
    """כל השירים בתיקייה ובתתי-התיקיות (לניגון תיקייה שלמה או לשמירה בטלפון)."""
    d = (request.args.get("dir") or "").strip("/")
    pre = d + "/" if d else ""
    return jsonify({"files": [{"p": rel, "s": size} for rel, size in music_index() if rel.startswith(pre)][:5000]})


def _range(size):
    h = request.headers.get("Range", "")
    m = re.match(r"bytes=(\d*)-(\d*)$", h.strip())
    if not m or (not m.group(1) and not m.group(2)):
        return 0, size - 1, False
    if m.group(1):
        a = int(m.group(1)); b = int(m.group(2)) if m.group(2) else size - 1
    else:
        a = max(0, size - int(m.group(2))); b = size - 1
    return a, min(b, size - 1), True


@app.route("/music/<path:rel>")
@login_required
def music_file(rel):
    rel = _clean_rel(rel)
    if not rel or not rel.lower().endswith(AUDIO_EXT):
        return Response(status=404)
    mime = mimetypes.guess_type(rel)[0] or "audio/mpeg"
    cached = mcache_path(rel)
    if os.path.isfile(cached):     # הועתק מראש לשרת: מגיע מהר
        return send_file(cached, mimetype=mime, conditional=True, max_age=86400)
    c = smb_cfg()
    if not c:
        full = os.path.realpath(os.path.join(MUSIC, rel))
        if not full.startswith(os.path.realpath(MUSIC) + os.sep) or not os.path.isfile(full):
            return Response(status=404)
        return send_file(full, mimetype=mime, conditional=True, max_age=86400)
    try:
        conn = smb_conn(c)
        size = conn.getAttributes(c["share"], "/" + rel, timeout=15).file_size
    except Exception:
        return jsonify({"error": "pc-off", "message": "המחשב כבוי או לא מחובר, אז השיר לא זמין עכשיו"}), 503
    a, b, partial = _range(size)
    if size == 0 or a > b:
        conn.close()
        return Response(status=416, headers={"Content-Range": "bytes */%d" % size})

    def gen():
        pos, chunk = a, 256 * 1024
        try:
            while pos <= b:
                n = min(chunk, b - pos + 1)
                buf = io.BytesIO()
                conn.retrieveFileFromOffset(c["share"], "/" + rel, buf, pos, n, timeout=30)
                data = buf.getvalue()
                if not data:
                    break
                yield data
                pos += len(data)
        finally:
            conn.close()

    hdr = {"Accept-Ranges": "bytes", "Content-Length": str(b - a + 1), "Cache-Control": "private, max-age=86400"}
    if partial:
        hdr["Content-Range"] = "bytes %d-%d/%d" % (a, b, size)
    return Response(gen(), status=206 if partial else 200, mimetype=mime, headers=hdr, direct_passthrough=True)


APK_DIR = os.path.join(DATA, "apk")


@app.route("/api/apk")
def api_apk():
    """גרסת אפליקציית הטלפון שנבנתה בשרת הביתי (לעדכון מתוך האפליקציה)."""
    try:
        with open(os.path.join(APK_DIR, "version.txt"), encoding="utf-8") as f:
            v = f.read().strip()
        size = os.path.getsize(os.path.join(APK_DIR, "fitness-sync.apk"))
        return jsonify({"version": v, "size": size, "url": "apk/fitness-sync-v%s.apk" % v})
    except OSError:
        return jsonify({"version": None})


@app.route("/apk/<name>")
def apk_file(name):
    if not re.fullmatch(r"fitness-sync(-v[\d.]+)?\.apk", name):
        return Response(status=404)
    return send_from_directory(APK_DIR, "fitness-sync.apk", mimetype="application/vnd.android.package-archive",
                               as_attachment=True, download_name=name, max_age=0)


if __name__ == "__main__":
    print("יומן כושר ביתי פועל: http://localhost:5050  (סיסמה ראשונית: %s)" % DEFAULT_PASSWORD)
    app.run(host="0.0.0.0", port=5050, debug=False)
